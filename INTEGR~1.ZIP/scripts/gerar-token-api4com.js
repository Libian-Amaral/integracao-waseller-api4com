// =====================================================================
//  Gera um Token de Acesso PERMANENTE da API4COM (ttl = -1).
//
//  Uso:  npm run gerar-token:api4com
//
//  O script pede o seu e-mail e a sua senha da API4COM, faz o login e
//  cria um token que nao expira. Nada e salvo em disco - voce copia o
//  token gerado e cola no .env, no campo API4COM_TOKEN.
//
//  Baseado na documentacao de Autenticacao da API4COM:
//  https://developers.api4com.com/authentication.html
// =====================================================================

const readline = require('readline');

const BASE_URL = 'https://api.api4com.com/api/v1';

// Pergunta normal (texto visivel).
function pergunta(texto) {
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });
  return new Promise((resolve) => {
    rl.question(texto, (resp) => {
      rl.close();
      resolve(resp.trim());
    });
  });
}

// Pergunta de senha: escreve o texto do prompt e, em seguida, silencia a
// saida para que os caracteres digitados nao aparecam na tela. Nao usa
// caracteres de controle, entao funciona de forma estavel.
function perguntaSenha(texto) {
  return new Promise((resolve) => {
    const rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout,
    });
    let promptEscrito = false;
    rl._writeToOutput = function (str) {
      if (!promptEscrito) {
        rl.output.write(str);
        promptEscrito = true; // depois do prompt, nao escreve mais nada
      }
    };
    rl.question(texto, (resp) => {
      rl.close();
      process.stdout.write('\n');
      resolve(resp.trim());
    });
  });
}

async function postJson(rota, corpo, token) {
  const headers = { 'Content-Type': 'application/json' };
  if (token) headers.Authorization = token;
  const resp = await fetch(BASE_URL + rota, {
    method: 'POST',
    headers,
    body: JSON.stringify(corpo),
  });
  const texto = await resp.text();
  let dados;
  try {
    dados = texto ? JSON.parse(texto) : {};
  } catch {
    dados = { raw: texto };
  }
  if (!resp.ok) {
    throw new Error(`HTTP ${resp.status} em ${rota}: ${texto}`);
  }
  return dados;
}

(async () => {
  console.log('=== Gerar token permanente da API4COM ===\n');
  const email = await pergunta('E-mail da API4COM: ');
  const senha = await perguntaSenha('Senha da API4COM: ');

  if (!email || !senha) {
    console.error('\nE-mail e senha sao obrigatorios.');
    process.exit(1);
  }

  try {
    console.log('\n1/2 - Fazendo login...');
    const login = await postJson('/users/login', { email, password: senha });
    const tokenTemporario = login.id;
    if (!tokenTemporario) {
      throw new Error('A API4COM nao retornou um token de login.');
    }

    console.log('2/2 - Criando token permanente (ttl = -1)...');
    const permanente = await postJson(
      '/users/accessTokens',
      { ttl: -1 },
      tokenTemporario
    );

    console.log('\n==============================================');
    console.log(' TOKEN PERMANENTE GERADO COM SUCESSO');
    console.log('==============================================');
    console.log('\nCopie a linha abaixo para o seu arquivo .env:\n');
    console.log('API4COM_TOKEN=' + permanente.id);
    console.log(
      '\n(Guarde este token com seguranca - ele da acesso a sua conta API4COM.)'
    );
  } catch (e) {
    console.error('\nFALHOU:', e.message);
    console.error('Confira o e-mail e a senha e tente novamente.');
    process.exit(1);
  }
})();
