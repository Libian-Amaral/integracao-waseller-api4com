// =====================================================================
//  Lista as etiquetas do WaSeller e seus IDs.
//
//  Uso:  node scripts/listar-etiquetas-waseller.js
//
//  Use isto para descobrir os "labelId" que vao no .env, caso voce queira
//  que a integracao marque automaticamente o resultado da ligacao com uma
//  etiqueta (WASELLER_LABEL_ATENDIDA / WASELLER_LABEL_NAO_ATENDIDA).
//
//  Pre-requisito no .env:  WASELLER_TOKEN
//  Lembre-se: a API do WaSeller exige o WhatsApp Web aberto e conectado.
// =====================================================================

require('dotenv').config();
const waseller = require('../lib/waseller');

(async () => {
  if (!process.env.WASELLER_TOKEN) {
    console.error('ERRO: configure WASELLER_TOKEN no .env antes de rodar este script.');
    process.exit(1);
  }

  console.log('Buscando etiquetas no WaSeller...\n');
  try {
    const r = await waseller.listarEtiquetas();
    console.log('Resposta do WaSeller:');
    console.log(JSON.stringify(r, null, 2));
    console.log(
      '\nProcure o "id" (ou "labelId") de cada etiqueta na resposta acima e'
    );
    console.log('coloque o valor desejado no .env.');
  } catch (e) {
    console.error('FALHOU:', e.message);
    console.error(
      'Se aparecer erro 501, verifique se o WhatsApp Web / WaSeller esta aberto e conectado.'
    );
    process.exit(1);
  }
})();
