// =====================================================================
//  Script de configuracao - registra na API4COM o webhook que avisa
//  este servico quando uma ligacao termina.
//
//  Uso:  npm run setup:api4com
//
//  Pre-requisitos no .env:
//   - API4COM_TOKEN   (token permanente da API4COM)
//   - PUBLIC_URL      (URL publica do servico, ex: https://...onrender.com)
//   - WEBHOOK_SECRET  (o mesmo segredo usado no servico)
// =====================================================================

require('dotenv').config();
const api4com = require('../lib/api4com');

(async () => {
  const publicUrl = process.env.PUBLIC_URL;
  const secret = process.env.WEBHOOK_SECRET;
  const gateway = process.env.API4COM_GATEWAY || 'waseller-api4com';

  if (!process.env.API4COM_TOKEN) {
    console.error('ERRO: configure API4COM_TOKEN no .env antes de rodar este script.');
    process.exit(1);
  }
  if (!publicUrl) {
    console.error('ERRO: configure PUBLIC_URL no .env (ex: https://seu-app.onrender.com).');
    process.exit(1);
  }
  if (!secret) {
    console.error('ERRO: configure WEBHOOK_SECRET no .env.');
    process.exit(1);
  }

  const webhookUrl = `${publicUrl.replace(/\/$/, '')}/webhook/api4com/${secret}`;

  console.log('Registrando o webhook de retorno na API4COM...');
  console.log('  gateway    :', gateway);
  console.log('  webhook URL:', webhookUrl);
  console.log('');

  try {
    const r = await api4com.registrarWebhook({ gateway, webhookUrl });
    console.log('OK! Integracao registrada com sucesso na API4COM.');
    console.log('Resposta da API4COM:');
    console.log(JSON.stringify(r, null, 2));
  } catch (e) {
    console.error('FALHOU:', e.message);
    process.exit(1);
  }
})();
